package org.fpc.chfs;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ChfsApplicationTests {

	@Test
	void contextLoads() {
	}

}
