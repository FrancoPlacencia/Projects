package com.fp.jeopardyapi;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class JeopardyApiApplicationTests {

	@Test
	void contextLoads() {
	}

}
