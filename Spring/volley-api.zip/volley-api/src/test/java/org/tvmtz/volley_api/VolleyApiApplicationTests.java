package org.tvmtz.volley_api;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class VolleyApiApplicationTests {

	@Test
	void contextLoads() {
	}

}
